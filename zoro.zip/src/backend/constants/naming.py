
PROJECT_TITLE="Zoro AI"
PROJECT_DESCRIPTION=f"{PROJECT_TITLE} built purely in Python(FastAPI) + PostgreSQL(Supabase) + OpenRouter"
PROJECT_VERSION="1.0.0"
MAIN_API_PREFIX="/api/v1"
AUTH_API_PREFIX="/auth"
USERS_API_PREFIX="/users"
CHAT_API_PREFIX="/chat"
